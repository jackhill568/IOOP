import java.util.Scanner;

public class EANBarcodeCompleter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);

        System.out.println("Enter the barcode prefix");
        String barcodePrefix = scanner.nextLine();

        // Write your solution to Task 1 here
        
        scanner.close();
    }
}

